<?php
echo 'receiving IPN message...';
?>