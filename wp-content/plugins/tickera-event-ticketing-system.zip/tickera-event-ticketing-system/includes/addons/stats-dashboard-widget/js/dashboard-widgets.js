jQuery( document ).ready( function( $ ) {
    $( ".tc-bar" ).peity( "bar", {
        width: 100,
        height: 32,
        delimiter: "|"
    } );
} );
